<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <!-- Styles CSS ici -->
    <style>
    body {
        background: url('../asset/sss.jpg') center/cover no-repeat; /* Set the path to your background image */
        color: #333333;
        font-family: 'Arial', sans-serif;
        margin: 0;
        padding: 0;
    }

    header {
        background-color: #333333;
        padding: 20px;
        text-align: center;
    }

    header img {
        background-color: transparent;
        border-radius: 50%;
    }

    h1 {
        color: #FFA500;
        margin-bottom: 10px;
    }

    h2 {
        color: #000000;
        font-size: 24px;
    }

    form {
        margin-bottom: 20px;
    }

    select, button {
        padding: 10px;
        border: none;
        border-radius: 4px;
        margin-right: 10px;
        cursor: pointer;
    }

    select {
        background-color: #FFFFFF;
    }

    button {
        background-color: #FFA500;
        color: #000000;
    }

    .gallery {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
    }

    .filter-buttons {
        text-align: center; /* Center the filter buttons */
        margin-bottom: 20px;
    }

    .filter-button {
        background-color: #FFA500;
        color: #FFFFFF;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        margin-right: 10px;
        display: inline-block;
    }

    .filter-button:hover {
        background-color: #FF8C00;
    }

    .piece {
        background-color: #FFFFFF;
        padding: 20px;
        border: 1px solid #E0E0E0;
        border-radius: 8px;
        margin-bottom: 10px; /* Reduced margin to bring pieces closer */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s ease-in-out;
    }

    .add-oeuvre-button {
        display: inline-block;
        padding: 10px 20px;
        margin: 20px auto; /* Adjust margin as needed */
        text-decoration: none;
        background-color: #FFA500; /* Orange background color */
        color: #000000; /* Black text color */
        border-radius: 4px;
        transition: background-color 0.2s ease-in-out;
    }

    .add-oeuvre-button:hover {
        background-color: #FFD700; /* Lighter orange on hover */
    }

    .piece:hover {
        transform: scale(1.05);
    }

    .piece img {
        max-width: 100%;
        height: auto;
        border-radius: 8px;
        transition: transform 0.2s ease-in-out;
    }

    .piece:hover img {
        transform: scale(1.1);
    }

    .piece h3 {
    font-family: 'Georgia', serif; /* Use a serif font for a more luxurious feel */
    font-size: 24px; /* Adjust the font size */
    color: #800080; /* Dark purple text color for a luxurious touch */
    text-transform: uppercase; /* Convert text to uppercase for a sophisticated look */
    letter-spacing: 2px; /* Increase letter spacing for an elegant appearance */
}
    .piece p {
    font-size: 16px; /* Adjust the font size for other text elements */
    color: #333333; /* Dark gray text color */
    font-style: italic; /* Use italic for added elegance */
}

    .pagination {
        text-align: center;
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
    }

    .pagination a {
        display: inline-block;
        padding: 8px 12px;
        margin: 0 5px;
        text-decoration: none;
        color: #FFA500; /* Orange text color */
        font-size: 16px;
        transition: font-size 0.2s ease-in-out;
    }

    .pagination a:hover {
        font-size: 18px; /* Increase font size on hover */
    }
</style>


</head>
<body>
    <header>
        <img src="../asset/logo.png" alt="Logo" width="150" height="150">
    </header>
    <h1>Bienvenue sur notre Galerie d'Art</h1>
    <h2>Toutes les Œuvres</h2>
    
    <form method="get" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <label for="tri">Trier par prix:</label>
        <select name="tri" id="tri">
            <option value="asc">Croissant</option>
            <option value="desc">Décroissant</option>
        </select>
        <button type="submit">Trier</button>
    </form>

    <!-- Filter buttons for specific types -->
    <div class="filter-buttons">
    <button class="filter-button" onclick="filterByType(0)">Toutes les œuvres</button>
    <button class="filter-button" onclick="filterByType(1)">Peinture</button>
    <button class="filter-button" onclick="filterByType(2)">Sculpture</button>
    <button class="filter-button" onclick="filterByType(3)">Poterie</button>
</div>

    <div class="gallery">
   
<?php
require_once('../controller/categorieC.php');

// Instantiate the CategorieC class
$controller = new CategorieC();

// Items per page
$itemsPerPage = 10  ;

// Retrieve the total number of pieces
$totalPieces = $controller->getTotalPieces();
$totalPages = ceil($totalPieces / $itemsPerPage);

// Get the current page, default to 1
$current_page = isset($_GET['page']) ? max(1, $_GET['page']) : 1;

// Calculate the offset for the query
$offset = ($current_page - 1) * $itemsPerPage;

// Retrieve pieces of artwork with sorting option and pagination
$tri = isset($_GET['tri']) ? $_GET['tri'] : 'asc';
$pieces = $controller->getAllPiecesWithPagination($tri, $itemsPerPage, $offset);

// Check if there are no pieces
if (empty($pieces)) {
    echo "Il n'y a pas d'œuvre pour le moment.";
} else {
    // Display category, title, image, and price of all pieces
    foreach ($pieces as $piece) {
        echo "<div class='piece' data-type='" . htmlspecialchars($piece['category']) . "'>";
        
        // Map category numbers to corresponding names
        $categoryNames = [
            1 => 'Peinture',
            2 => 'Sculpture',
            3 => 'Poterie',
        ];
        
        $categoryName = isset($categoryNames[$piece['category']]) ? $categoryNames[$piece['category']] : 'Inconnu';
    
        echo "<p>Catégorie: " . htmlspecialchars($categoryName) . "</p>";
        echo "<h3><a href='view_oeuvre.php?id=" . htmlspecialchars($piece['id_piece_doeuvre']) . "'>" . htmlspecialchars($piece['titre']) . "</a></h3>";
        echo "<img src='" . htmlspecialchars($piece['image']) . "' alt='Image de l'œuvre' width='100'><br>";
        echo "<p>Prix: " . htmlspecialchars($piece['prix']) . "</p>";
        echo "</div>";
        echo "<br>";
    }

    // Display pagination links if there are more than one page
    if ($totalPages > 1) {
        echo "<div class='pagination'>";
        for ($i = 1; $i <= $totalPages; $i++) {
            $activeClass = ($i == $current_page) ? "active" : "";
            echo "<a href='?page=$i&tri=$tri' class='page-link $activeClass'>$i</a>";
        }
        echo "</div>";
    }
}
?>



    </div>
    <a href="../View/addOeuvre.php" class="add-oeuvre-button">Ajouter une oeuvre</a>
 <script>
        function filterByType(type) {
            var pieces = document.getElementsByClassName('piece');
            for (var i = 0; i < pieces.length; i++) {
                var pieceType = pieces[i].getAttribute('data-type');
                if (type.toString() === pieceType || type === 0) {
                    pieces[i].style.display = 'block';
                } else {
                    pieces[i].style.display = 'none';
                }
            }
        }
    </script>
</body>
</html>
